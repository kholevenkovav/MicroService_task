#!/usr/bin/env bash
set -euo pipefail

BASE="http://localhost:8013"

echo "[1] io_ids:"
curl -s "$BASE/scenarios/io_ids" | head -c 500
echo
echo

IO=$(curl -s "$BASE/scenarios/io_ids" | python -c "import sys,json; print(json.load(sys.stdin)[0])")
echo "[2] selected io_id=$IO"

echo "[3] param_grid(IF) first preset:"
curl -s "$BASE/scenarios/param_grid?model=IF" | python -c "import sys,json; d=json.load(sys.stdin); print(d['params'][0])"
echo

echo "[4] evaluate_once (single run):"
curl -s -X POST "$BASE/scenarios/evaluate_once" -H 'Content-Type: application/json' -d "{\"io_id\":\"$IO\",\"size\":\"70_30\",\"shift\":0,\"window_size\":10,\"encoding\":\"one_hot\",\"model\":\"IF\",\"param_index\":0}" | head -c 800
echo

echo "[5] evaluate_and_store (creates run in Storage):"
curl -s -X POST "$BASE/scenarios/evaluate_and_store" -H 'Content-Type: application/json' -d "{\"note\":\"demo\",\"io_id\":\"$IO\",\"size\":\"70_30\",\"shift\":0,\"window_size\":10,\"encoding\":\"one_hot\",\"model\":\"IF\",\"param_index\":0}" | tee /tmp/eval_store.json
echo

RID=$(python - <<'PY'
import json
d=json.load(open("/tmp/eval_store.json"))
print(d.get("run_id",""))
PY
)

echo "[6] run_id=$RID"
echo "[7] metrics by run_id:"
curl -s "$BASE/scenarios/metrics?run_id=$RID" | head -c 800
echo
