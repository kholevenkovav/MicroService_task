from pydantic import BaseModel, Field
from typing import Dict, Optional, Any


class RunCreate(BaseModel):

    note: str = "ml-run"
    config_json: Dict[str, Any] = Field(default_factory=dict)


class MetricCreate(BaseModel):

    run_id: Optional[int] = None
    io_id: str
    model: str
    size: str
    shift: int
    window_size: int
    encoding: str
    params: Dict[str, Any] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(default_factory=dict)
