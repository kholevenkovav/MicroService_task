import os
import json
import requests
import pandas as pd

from dash import Dash, dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objs as go


WEBMASTER = os.getenv("WEBMASTER_URL", "http://webmaster:8000")


def _get(path: str, params=None, timeout=30):
    return requests.get(f"{WEBMASTER}{path}", params=params, timeout=timeout)


def _post(path: str, payload: dict, timeout=600):
    return requests.post(f"{WEBMASTER}{path}", json=payload, timeout=timeout)


def fetch_io_ids() -> list[str]:
    try:
        r = _get("/scenarios/io_ids", timeout=15)
        if r.status_code != 200:
            return []
        data = r.json() or []
        return sorted([str(x) for x in data])
    except requests.RequestException:
        return []


MODELS = ["IF", "OCSVM", "LOF", "PCA", "IF-PCA", "OCSVM-PCA"]
ENCODINGS = ["one_hot", "sin_cos", "cyclic", "sin_cos_cyclic"]
SPLITS = ["70_30", "50_50", "30_70"]
WINDOWS = [5, 10, 15, 30, 60]
SHIFTS = [0, 1, 2, 3, 4]


def _parse_params(raw: str) -> dict:
    raw = (raw or "").strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {"_error": "params is not valid JSON"}


def _compact_params(p: dict) -> str:
    if not isinstance(p, dict):
        return str(p)
    order = [
        "n_components",
        "n_estimators",
        "n_neighbors",
        "leaf_size",
        "nu",
        "kernel",
        "contamination",
        "max_samples",
        "max_features",
        "random_state",
    ]
    parts = []
    for k in order:
        if k in p:
            parts.append(f"{k}={p[k]}")
    # add any remaining keys (rare)
    for k in sorted(p.keys()):
        if k not in order:
            parts.append(f"{k}={p[k]}")
    s = ", ".join(parts)
    if len(s) > 110:
        s = s[:110] + "…"
    return s


def fig_metrics(metrics: dict) -> go.Figure:
    if not metrics:
        return go.Figure()
    keys = list(metrics.keys())
    vals = [metrics.get(k) for k in keys]
    fig = go.Figure(data=[go.Bar(x=keys, y=vals)])
    fig.update_layout(
        title="Метрики",
        yaxis_title="Значение",
        xaxis_title="Метрика",
        margin=dict(l=30, r=30, t=60, b=30),
        height=340,
    )
    return fig


def fig_temperature(points: list[dict], title: str) -> go.Figure:
    if not points:
        return go.Figure()
    dfp = pd.DataFrame(points)
    dfp["dt"] = pd.to_datetime(dfp["event_timestamp"], unit="s", utc=True)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dfp["dt"], y=dfp["value"], mode="lines", name="Температура"))

    true = dfp[dfp.get("y_true", 0) == 1] if "y_true" in dfp.columns else pd.DataFrame()
    if not true.empty:
        fig.add_trace(go.Scatter(x=true["dt"], y=true["value"], mode="markers", name="Аномалия (y_test=1)"))

    pred = dfp[dfp.get("y_pred", 0) == 1] if "y_pred" in dfp.columns else pd.DataFrame()
    if not pred.empty:
        fig.add_trace(go.Scatter(x=pred["dt"], y=pred["value"], mode="markers", name="Предсказано (y_pred=1)"))

    fig.update_layout(
        title=title,
        xaxis_title="Дата",
        yaxis_title="Температура (°C)",
        margin=dict(l=30, r=30, t=60, b=30),
        height=480,
    )
    return fig


def fig_scores(points: list[dict], threshold: float | None) -> go.Figure:
    if not points:
        return go.Figure()
    dfp = pd.DataFrame(points)
    dfp["dt"] = pd.to_datetime(dfp["event_timestamp"], unit="s", utc=True)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dfp["dt"], y=dfp["score"], mode="lines", name="Скор"))
    if threshold is not None:
        fig.add_trace(
            go.Scatter(
                x=[dfp["dt"].min(), dfp["dt"].max()],
                y=[threshold, threshold],
                mode="lines",
                name="Порог",
            )
        )

    pred = dfp[dfp.get("y_pred", 0) == 1] if "y_pred" in dfp.columns else pd.DataFrame()
    if not pred.empty:
        fig.add_trace(go.Scatter(x=pred["dt"], y=pred["score"], mode="markers", name="Предсказано (y_pred=1)"))

    fig.update_layout(
        title="Скор (чем выше - тем аномальнее)",
        xaxis_title="Дата",
        yaxis_title="Скор",
        margin=dict(l=30, r=30, t=60, b=30),
        height=360,
    )
    return fig


app = Dash(__name__, external_stylesheets=[dbc.themes.FLATLY])
server = app.server

io_ids0: list[str] = []


app.layout = dbc.Container(
    [
        dcc.Interval(id="init-io-interval", interval=1500, n_intervals=0, max_intervals=40),
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.H2("Детекция аномалий"),
                    ]
                ),
                dbc.Col(
                    dbc.Button(
                        "Проверить статус",
                        id="btn-status",
                        color="secondary",
                        outline=True,
                        className="mt-3 float-end",
                    ),
                    width=3,
                ),
            ],
            className="mt-3",
        ),
        dbc.Alert(id="status-box", color="info", className="mt-2", is_open=False),

        dcc.Store(id="param-grid-store"),

        dbc.Card(
            dbc.CardBody(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                [
                                    dbc.Label("IO_ID (датчик)"),
                                    dcc.Dropdown(io_ids0, io_ids0[0] if io_ids0 else None, id="io"),
                                ],
                                md=4,
                            ),
                            dbc.Col(
                                [dbc.Label("Split"), dcc.Dropdown(SPLITS, "70_30", id="split")],
                                md=2,
                            ),
                            dbc.Col(
                                [dbc.Label("Shift"), dcc.Dropdown(SHIFTS, 0, id="shift")],
                                md=2,
                            ),
                            dbc.Col(
                                [dbc.Label("Window (мин)"), dcc.Dropdown(WINDOWS, 10, id="window")],
                                md=2,
                            ),
                            dbc.Col(
                                [dbc.Label("Encoding"), dcc.Dropdown(ENCODINGS, "one_hot", id="encoding")],
                                md=2,
                            ),
                        ],
                        className="g-2",
                    ),
                    dbc.Row(
                        [
                            dbc.Col(
                                [dbc.Label("Model"), dcc.Dropdown(MODELS, "IF", id="model")],
                                md=3,
                            ),
                            dbc.Col(
                                [
                                    dbc.Label("Params"),
                                    dcc.Dropdown([], None, id="param-preset", optionHeight=45, maxHeight=320),
                                ],
                                md=3,
                            ),
                            dbc.Col(
                                [
                                    dbc.Label("Params override - JSON (опционально)"),
                                    dbc.Input(
                                        id="params",
                                        placeholder='н-р: {"n_estimators":200,"contamination":0.04}',
                                        value="",
                                    ),
                                ],
                                md=6,
                            ),
                        ],
                        className="g-2 mt-2",
                    ),
                    dbc.Row(
                        [
                            dbc.Col(dbc.Button("Показать границы train/test", id="btn-dataset", color="primary"), md="auto"),
                            dbc.Col(dbc.Button("Evaluate", id="btn-eval", color="success"), md="auto"),
                            dbc.Col(
                                dbc.Checklist(
                                    options=[{"label": "Сохранить результат", "value": 1}],
                                    value=[],
                                    id="save-flag",
                                    switch=True,
                                ),
                                md="auto",
                            ),
                            dbc.Col(
                                dbc.Input(
                                    id="run-note",
                                    placeholder="Название прогона (если сохраняем)",
                                    value="single-eval",
                                ),
                                md=4,
                            ),
                        ],
                        className="g-2 mt-3",
                    ),
                    html.Hr(),
                    html.Div(id="dataset-meta"),
                    html.Div(id="preset-json", className="text-muted", style={"whiteSpace": "pre-wrap"}),
                ]
            ),
            className="mt-3",
        ),

        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.H4("Результат"),
                                dcc.Graph(id="metrics-graph"),
                                html.Pre(id="metrics-json", style={"whiteSpace": "pre-wrap"}),
                            ]
                        )
                    ),
                    md=4,
                ),
                dbc.Col(
                    dbc.Card(dbc.CardBody([html.H4("Температура"), dcc.Graph(id="temp-graph")])),
                    md=8,
                ),
            ],
            className="mt-3 g-3",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(dbc.CardBody([dcc.Graph(id="scores-graph")]))
                )
            ],
            className="mt-3 g-3",
        ),
        html.Div(className="mb-4"),
    ],
    fluid=True,
)


@app.callback(
    Output("io", "options"),
    Output("io", "value"),
    Input("init-io-interval", "n_intervals"),
    State("io", "options"),
    State("io", "value"),
)
def init_io_ids(_n, current_opts, current_val):
    if current_opts:
        return current_opts, current_val
    ids = fetch_io_ids()
    if not ids:
        return [], current_val
    if current_val in ids:
        return ids, current_val
    return ids, ids[0]


@app.callback(
    Output("status-box", "is_open"),
    Output("status-box", "children"),
    Input("btn-status", "n_clicks"),
    prevent_initial_call=True,
)
def on_status(_):
    r = _get("/scenarios/status", timeout=30)
    if r.status_code != 200:
        return True, f"Ошибка: {r.status_code} {r.text}"
    return True, json.dumps(r.json(), ensure_ascii=False, indent=2)


@app.callback(
    Output("dataset-meta", "children"),
    Input("btn-dataset", "n_clicks"),
    State("io", "value"),
    State("split", "value"),
    State("shift", "value"),
    prevent_initial_call=True,
)
def on_dataset(_, io_id, split, shift):
    if not io_id:
        return dbc.Alert("Выбери io_id", color="warning")
    r = _get(
        "/scenarios/dataset",
        params={"io_id": str(io_id), "split": str(split), "shift": int(shift or 0)},
        timeout=60,
    )
    if r.status_code != 200:
        return dbc.Alert(f"Ошибка: {r.status_code} {r.text}", color="danger")
    meta = (r.json() or {}).get("meta") or {}

    def _fmt_span(span) -> str:
        if not span or not isinstance(span, (list, tuple)) or len(span) != 2:
            return "—"
        return f"{span[0]} → {span[1]}"

    tr_span = _fmt_span(meta.get("train_span"))
    te_span = _fmt_span(meta.get("test_span"))
    tr_range = meta.get("train_range") or {}
    te_range = meta.get("test_range") or {}

    head = dbc.Alert(
        f"io_id={meta.get('io_id')} | split={meta.get('split')} | shift={meta.get('shift_index')} (={meta.get('shift_days')} дней) | ресемплинг={meta.get('resample_rule')}",
        color="info",
    )

    train_card = dbc.Card(
        dbc.CardBody(
            [
                html.H6("Train"),
                html.Ul(
                    [
                        html.Li(f"Дни: {meta.get('train_days')} (диапазон: {tr_span})"),
                        html.Li(
                            f"Временной диапазон: {tr_range.get('date_min','—')} → {tr_range.get('date_max','—')}"
                        ),
                        html.Li(f"Точек (после ресемпла): {tr_range.get('rows','—')}"),
                    ]
                ),
            ]
        ),
        className="h-100",
    )

    test_card = dbc.Card(
        dbc.CardBody(
            [
                html.H6("Test"),
                html.Ul(
                    [
                        html.Li(f"Дни: {meta.get('test_days')} (диапазон: {te_span})"),
                        html.Li(
                            f"Временной диапазон: {te_range.get('date_min','—')} → {te_range.get('date_max','—')}"
                        ),
                        html.Li(f"Точек (после ресемпла): {te_range.get('rows','—')}"),
                    ]
                ),
            ]
        ),
        className="h-100",
    )

    tail = html.Div(
        f"Всего уникальных суток: {meta.get('unique_days')} (в датасете: {meta.get('dates_first_last',[None,None])[0]} → {meta.get('dates_first_last',[None,None])[1]})",
        className="text-muted",
    )

    return html.Div(
        [
            head,
            dbc.Row([dbc.Col(train_card, md=6), dbc.Col(test_card, md=6)], className="g-2"),
            html.Div(className="mt-2"),
            tail,
        ]
    )


@app.callback(
    Output("param-grid-store", "data"),
    Output("param-preset", "options"),
    Output("param-preset", "value"),
    Output("preset-json", "children"),
    Input("model", "value"),
)
def on_model_change(model):
    r = _get("/scenarios/param_grid", params={"model": str(model)}, timeout=30)
    if r.status_code != 200:
        return [], [], None, f"Не удалось получить param_grid: {r.status_code} {r.text}"
    data = r.json() or {}
    params = data.get("params") or []
    options = [{"label": f"#{i}: {_compact_params(p)}", "value": i} for i, p in enumerate(params)]
    default_value = 0 if options else None
    preview = json.dumps(params[0], ensure_ascii=False, indent=2) if params else ""
    return params, options, default_value, preview


@app.callback(
    Output("metrics-graph", "figure"),
    Output("temp-graph", "figure"),
    Output("scores-graph", "figure"),
    Output("metrics-json", "children"),
    Output("preset-json", "children", allow_duplicate=True),
    Input("btn-eval", "n_clicks"),
    State("io", "value"),
    State("split", "value"),
    State("shift", "value"),
    State("window", "value"),
    State("encoding", "value"),
    State("model", "value"),
    State("param-preset", "value"),
    State("param-grid-store", "data"),
    State("params", "value"),
    State("save-flag", "value"),
    State("run-note", "value"),
    prevent_initial_call=True,
)
def on_evaluate(_, io_id, split, shift, window, encoding, model, preset_idx, grid, params_raw, save_flag, run_note):
    if not io_id:
        return go.Figure(), go.Figure(), go.Figure(), "Выбери io_id", ""

    params_override = _parse_params(params_raw)
    if "_error" in params_override:
        return go.Figure(), go.Figure(), go.Figure(), params_override["_error"], ""

    payload = {
        "io_id": str(io_id),
        "size": str(split),
        "shift": int(shift or 0),
        "window_size": int(window),
        "encoding": str(encoding),
        "model": str(model),
    }

    if params_override:
        payload["params"] = params_override
    else:
        payload["param_index"] = int(preset_idx or 0)

    do_save = 1 in (save_flag or [])
    if do_save:
        payload2 = dict(payload)
        payload2["note"] = str(run_note or "single-eval")
        r = _post("/scenarios/evaluate_and_store", payload2, timeout=1200)
        if r.status_code != 200:
            return go.Figure(), go.Figure(), go.Figure(), f"Ошибка: {r.status_code} {r.text}", ""
        data = (r.json() or {}).get("result") or {}
        run_id = (r.json() or {}).get("run_id")
    else:
        r = _post("/scenarios/evaluate_once", payload, timeout=1200)
        if r.status_code != 200:
            return go.Figure(), go.Figure(), go.Figure(), f"Ошибка: {r.status_code} {r.text}", ""
        data = r.json() or {}
        run_id = None

    metrics = data.get("metrics") or {}
    points = data.get("points") or []
    thr = data.get("threshold")

    fig_m = fig_metrics(metrics)
    fig_t = fig_temperature(points, "y_pred vs y_test")
    fig_s = fig_scores(points, thr)

    info = {
        "run_id": run_id,
        "metrics": metrics,
        "threshold": thr,
        "params": data.get("params"),
        "config": {k: data.get(k) for k in ["io_id", "model", "size", "shift", "window_size", "encoding"]},
    }

    preset_preview = ""
    if not params_override and grid:
        i = int(preset_idx or 0)
        if 0 <= i < len(grid):
            preset_preview = json.dumps(grid[i], ensure_ascii=False, indent=2)

    return fig_m, fig_t, fig_s, json.dumps(info, ensure_ascii=False, indent=2), preset_preview


if __name__ == "__main__":
    app.run_server(host="0.0.0.0", port=8050, debug=False)
