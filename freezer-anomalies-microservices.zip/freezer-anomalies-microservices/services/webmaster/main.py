import os
import yaml
import requests
from fastapi import FastAPI, HTTPException
from services_shared.utils import setup_logger

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["ml_url"] = os.getenv("ML_URL", cfg.get("ml_url", "http://ml:8000"))
    cfg["storage_url"] = os.getenv("STORAGE_URL", cfg.get("storage_url", "http://storage:8000"))
    cfg["collector_url"] = os.getenv("COLLECTOR_URL", cfg.get("collector_url", "http://collector:8000"))
    return cfg

cfg = load_config()
logger = setup_logger("webmaster", os.getenv("LOGS_DIR", "/logs"))

app = FastAPI(title="Web Master (API Gateway)", version="1.1")

UPSTREAM_TIMEOUT = float(os.getenv("UPSTREAM_TIMEOUT", "600"))

def _proxy(method: str, url: str, **kwargs):
    try:
        r = requests.request(method, url, timeout=UPSTREAM_TIMEOUT, **kwargs)
    except requests.RequestException as e:
        raise HTTPException(503, f"upstream error: {e}")
    if r.status_code != 200:
        raise HTTPException(r.status_code, r.text)
    return r.json()

@app.get("/scenarios/status")
def scenario_status():
    """Проверка, что внутренние сервисы подняты."""
    status_map: dict[str, bool] = {"webmaster": True}

    try:
        _proxy("GET", f"{cfg['collector_url']}/openapi.json")
        status_map["collector"] = True
    except Exception as e:
        logger.info(f"status.collector failed: {e}")
        status_map["collector"] = False

    try:
        _proxy("GET", f"{cfg['storage_url']}/openapi.json")
        status_map["storage"] = True
    except Exception as e:
        logger.info(f"status.storage failed: {e}")
        status_map["storage"] = False

    try:
        _proxy("GET", f"{cfg['ml_url']}/status")
        status_map["ml"] = True
    except Exception as e:
        logger.info(f"status.ml failed: {e}")
        status_map["ml"] = False

    dash_url = os.getenv("DASH_URL", cfg.get("dash_url", "http://visualization:8050"))
    try:
        r = requests.get(dash_url, timeout=5)
        status_map["visualization"] = bool(r.status_code == 200)
    except Exception as e:
        logger.info(f"status.visualization failed: {e}")
        status_map["visualization"] = False

    ok = all(status_map.values())
    return {"ok": ok, "services": [k for k, v in status_map.items() if v], "details": status_map}

@app.get("/scenarios/io_ids")
def scenario_io_ids():
    """Список датчиков"""
    return _proxy("GET", f"{cfg['collector_url']}/io_ids")

@app.get("/scenarios/param_grid")
def scenario_param_grid(model: str, contamination: float | None = None):
    """Получить список пресетов гиперпараметров для модели."""
    params = {"model": model}
    if contamination is not None:
        params["contamination"] = float(contamination)
    return _proxy("GET", f"{cfg['ml_url']}/param_grid", params=params)

@app.post("/scenarios/evaluate_once")
def scenario_evaluate_once(payload: dict):
    """Оценка одной комбинации (метрики + точки)."""
    logger.info(f"scenario.evaluate_once {payload}")
    return _proxy("POST", f"{cfg['ml_url']}/evaluate_once", json=payload)


@app.post("/scenarios/evaluate_and_store")
def scenario_evaluate_and_store(payload: dict):
    """Оценить одну комбинацию и сохранить метрики в Storage."""
    note = str(payload.pop("note", "single-eval"))
    run = _proxy("POST", f"{cfg['storage_url']}/runs/create", json={"note": note, "config_json": payload})
    run_id = int(run["run_id"])
    payload2 = dict(payload)
    payload2["save"] = True
    payload2["run_id"] = run_id
    res = scenario_evaluate_once(payload2)
    return {"run_id": run_id, "result": res}


@app.get("/scenarios/metrics")
def scenario_metrics(run_id: int | None = None, limit: int = 200, offset: int = 0):
    """Получить сохранённые метрики (по одному прогону)."""
    params = {"limit": int(limit), "offset": int(offset)}
    if run_id is not None:
        params["run_id"] = int(run_id)
    return _proxy("GET", f"{cfg['storage_url']}/metrics", params=params)


@app.get("/scenarios/runs")
def scenario_runs(limit: int = 50, offset: int = 0):
    """Список прогонов (runs)."""
    return _proxy("GET", f"{cfg['storage_url']}/runs", params={"limit": limit, "offset": offset})


@app.get("/scenarios/dataset")
def scenario_dataset(io_id: str, split: str = "70_30", shift: int = 0):
    """Получить train/test выборки из Collector."""
    return _proxy("GET", f"{cfg['collector_url']}/split", params={"io_id": io_id, "split": split, "shift": int(shift)})

@app.post("/scenarios/train_model")
def scenario_train_model(payload: dict):
    """Обучение и сохранение модели"""
    logger.info(f"scenario.train_model {payload}")
    return _proxy("POST", f"{cfg['ml_url']}/models/train", json=payload)

