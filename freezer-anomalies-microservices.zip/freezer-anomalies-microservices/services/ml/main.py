import os
import json
import time
import math
import datetime as dt
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import requests
from fastapi import FastAPI, HTTPException
from sklearn.preprocessing import RobustScaler
from sklearn.neighbors import LocalOutlierFactor
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib
import yaml

from services_shared.utils import setup_logger
from services_shared.schemas import MetricCreate

COLLECTOR_URL = os.getenv("COLLECTOR_URL", "http://collector:8000")
STORAGE_URL = os.getenv("STORAGE_URL", "http://storage:8000")
MODELS_DIR = os.getenv("MODELS_DIR", "/models")
LOGS_DIR = os.getenv("LOGS_DIR", "/logs")

HTTP_GET_TIMEOUT  = float(os.getenv("HTTP_GET_TIMEOUT", "120"))
HTTP_POST_TIMEOUT = float(os.getenv("HTTP_POST_TIMEOUT", "300"))

def load_config() -> dict:
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    if not os.path.exists(cfg_path):
        return {}
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${MODELS_DIR:/models}", MODELS_DIR)
    return yaml.safe_load(raw)

CFG = load_config() or {}

LOG = setup_logger("ml", LOGS_DIR)
os.makedirs(MODELS_DIR, exist_ok=True)


def save_model_artifact(
    *,
    model_name: str,
    params: Dict[str, Any],
    model: Any,
    scaler: Any,
    meta: Dict[str, Any],
    out_dir: str,
) -> None:
    os.makedirs(out_dir, exist_ok=True)
    bundle_path = os.path.join(out_dir, "bundle.joblib")
    meta_path = os.path.join(out_dir, "meta.json")
    joblib.dump({"model_name": model_name, "model": model, "scaler": scaler, "params": params, "meta": meta}, bundle_path)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

app = FastAPI(title="ML Service", version="1.3")

def http_get(url: str, tries: int = 3, delay: float = 0.5, **kwargs):
    for _ in range(tries):
        try:
            return requests.get(url, timeout=HTTP_GET_TIMEOUT, **kwargs)
        except requests.RequestException:
            time.sleep(delay)
    raise HTTPException(status_code=503, detail=f"GET failed: {url}")

def http_post(url: str, json_payload: dict, tries: int = 3, delay: float = 0.5, **kwargs):
    for _ in range(tries):
        try:
            return requests.post(url, json=json_payload, timeout=HTTP_POST_TIMEOUT, **kwargs)
        except requests.RequestException:
            time.sleep(delay)
    raise HTTPException(status_code=503, detail=f"POST failed: {url}")

def fetch_io_ids() -> List[str]:
    r = http_get(f"{COLLECTOR_URL}/io_ids")
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, list):
        raise HTTPException(500, "collector /io_ids returned non-list")
    return [str(x) for x in data]

def _normalize_split_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return pd.DataFrame()
    out = df.copy()
    out.columns = [c.strip().lower() for c in out.columns]
    if "anomaly" not in out.columns:
        out["anomaly"] = 0
    return out

def fetch_dataset(io_id: str, split: str, shift: int) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    params = {"io_id": io_id, "split": split, "shift": int(shift)}
    r = http_get(f"{COLLECTOR_URL}/split", params=params)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict) and "detail" in data:
        raise HTTPException(400, f"collector error: {data['detail']}")
    if not isinstance(data, dict) or "train" not in data or "test" not in data:
        raise HTTPException(500, "collector /split returned unexpected payload (expected {meta,train,test})")

    meta = data.get("meta", {}) or {}
    train_df = _normalize_split_df(pd.DataFrame(data.get("train") or []))
    test_df  = _normalize_split_df(pd.DataFrame(data.get("test") or []))
    return train_df, test_df, meta

def fetch_split(io_id: str, split: str, shift: int, part: str) -> pd.DataFrame:
    part_l = str(part).lower().strip()
    train_df, test_df, _ = fetch_dataset(io_id, split=split, shift=shift)
    if part_l == "train":
        return train_df
    if part_l == "test":
        return test_df
    raise HTTPException(400, "part must be train|test")

def create_time_features(df: pd.DataFrame, cyclic_points: int = 240, hour_min: bool = False, cyclic: bool = False):

    df = df.copy()
    df["datetime"] = pd.to_datetime(df["event_timestamp"], unit="s", utc=True)

    df["hour"] = df["datetime"].dt.hour.astype(int)
    df["minute"] = df["datetime"].dt.minute.astype(int)

    if (not hour_min) and (not cyclic):
        df["hour_cat"] = pd.Categorical(df["hour"], categories=list(range(24)))
        df["minute_cat"] = pd.Categorical(df["minute"], categories=list(range(60)))
        hour_features = pd.get_dummies(df["hour_cat"], prefix="hour", dtype=float)
        minute_features = pd.get_dummies(df["minute_cat"], prefix="minute", dtype=float)
        return pd.concat([hour_features, minute_features], axis=1), df["datetime"].copy()

    time_features: List[str] = []

    if hour_min:
        df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
        df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
        df["minute_sin"] = np.sin(2 * np.pi * df["minute"] / 60)
        df["minute_cos"] = np.cos(2 * np.pi * df["minute"] / 60)
        time_features += ["hour_sin", "hour_cos", "minute_sin", "minute_cos"]

    if cyclic:
        window = np.arange(len(df)) % int(cyclic_points)
        df["window_sin"] = np.sin(2 * np.pi * window / int(cyclic_points))
        df["window_cos"] = np.cos(2 * np.pi * window / int(cyclic_points))
        time_features += ["window_sin", "window_cos"]

    return df[time_features], df["datetime"].copy()

def _resample_minutely(df: pd.DataFrame, labeled: bool, rule: str) -> pd.DataFrame:

    if df is None or df.empty:
        return pd.DataFrame()
    out = df.copy().sort_values("event_timestamp")
    dt = pd.to_datetime(out["event_timestamp"].astype(int), unit="s", utc=True)
    out = out.assign(_dt=dt).set_index("_dt")

    agg = {"value": "mean"}
    if labeled:
        agg["anomaly"] = "max"

    if str(rule).lower().strip() in ("none", "raw", ""):
        if "anomaly" not in out.columns:
            out["anomaly"] = 0
        out = out[["event_timestamp", "value", "anomaly"]]
        return out.reset_index(drop=True)

    res = out.resample(rule).agg(agg)
    res = res.dropna(subset=["value"]).reset_index()
    res.rename(columns={"_dt": "datetime"}, inplace=True)
    res["event_timestamp"] = (res["datetime"].astype("int64") // 10**9).astype(int)
    if labeled:
        res["anomaly"] = res["anomaly"].fillna(0).astype(int)
    else:
        res["anomaly"] = 0
    return res[["event_timestamp", "value", "anomaly"]]


def sliding_window_features(df: pd.DataFrame, window_points: int = 10, window_label: str = "10m") -> pd.DataFrame:

    if df is None or df.empty or len(df) < int(window_points):
        return pd.DataFrame()

    v = df["value"].astype(float)
    w = int(window_points)
    r = v.rolling(window=w, min_periods=w)

    feat = pd.DataFrame(index=df.index)
    feat["value_cur"] = v
    feat[f"mean_{window_label}"] = r.mean()
    feat[f"std_{window_label}"] = r.std(ddof=0)
    feat[f"min_{window_label}"] = r.min()
    feat[f"max_{window_label}"] = r.max()
    feat[f"median_{window_label}"] = r.median()
    feat[f"var_{window_label}"] = r.var(ddof=0)
    feat[f"trend_{window_label}"] = v - v.shift(w - 1)
    feat[f"q25_{window_label}"] = r.quantile(0.25)
    feat[f"q75_{window_label}"] = r.quantile(0.75)

    feat = feat.dropna()
    return feat

def prepare_features(
    df: pd.DataFrame,
    io_id: str,
    hour_min: bool = False,
    cyclic: bool = False,
    window_points: int = 10,
    labeled: bool = False,
):

    cyclic_points = 244 if str(io_id).startswith("62") else 255
    rule = str(CFG.get("resample_rule", "1min"))

    df0 = _resample_minutely(df, labeled=labeled, rule=rule)
    if df0.empty:
        return pd.DataFrame(), pd.DataFrame()

    df0 = df0.sort_values("event_timestamp").reset_index(drop=True)
    df_t, _ = create_time_features(df0, cyclic_points=cyclic_points, hour_min=hour_min, cyclic=cyclic)
    df_window = sliding_window_features(df0, window_points=window_points, window_label=f"{window_points}m")

    if df_window.empty:
        return pd.DataFrame(), pd.DataFrame()

    df0_idx = pd.RangeIndex(start=0, stop=len(df0))
    df_t.index = df0_idx
    df_window.index = df_window.index.astype(int)

    t_aligned = df_t.loc[df_window.index].copy()
    base_aligned = df0.loc[df_window.index, ["event_timestamp", "value", "anomaly"]].copy().reset_index(drop=True)
    X = pd.concat([df_window.reset_index(drop=True), t_aligned.reset_index(drop=True)], axis=1)
    return X, base_aligned

def make_xy(train_df: pd.DataFrame, test_df: pd.DataFrame, io_id: str, window_points: int, encoding: str):
    hour_min = encoding in ["sin_cos", "sin_cos_cyclic"]
    cyclic = encoding in ["cyclic", "sin_cos_cyclic"]

    Xtr_df, tr_base = prepare_features(train_df, io_id=io_id, hour_min=hour_min, cyclic=cyclic, window_points=window_points, labeled=False)
    Xte_df, te_base = prepare_features(test_df,  io_id=io_id, hour_min=hour_min, cyclic=cyclic, window_points=window_points, labeled=True)

    if Xtr_df.empty or Xte_df.empty:
        return np.zeros((0, 0)), np.zeros((0, 0)), np.zeros((0,), dtype=int), [], [], None

    Xte_df = Xte_df.reindex(columns=Xtr_df.columns, fill_value=0.0)

    yte = te_base["anomaly"].fillna(0).astype(int).to_numpy()
    ts = te_base["event_timestamp"].astype(int).to_list()
    val = te_base["value"].astype(float).to_list()

    scaler = RobustScaler()
    Xtr = scaler.fit_transform(Xtr_df.values)
    Xte = scaler.transform(Xte_df.values)
    return Xtr, Xte, yte, ts, val, scaler

def normalize_model_name(name: str) -> str:
    n = str(name or "").strip()
    aliases = {
        "OneClassSVM": "OCSVM",
        "OneClassSvM": "OCSVM",
        "OneClassSvm": "OCSVM",
        "IsolationForest": "IF",
    }
    return aliases.get(n, n)


def model_grid(model_name: str, default_contamination: float) -> List[Dict[str, Any]]:
    model_name = normalize_model_name(model_name)
    c = float(default_contamination)
    if model_name == "LOF":
        return [
            {"n_neighbors": 20, "leaf_size": 30},
            {"n_neighbors": 30, "leaf_size": 30},
            {"n_neighbors": 50, "leaf_size": 30},
            {"n_neighbors": 100, "leaf_size": 30},
            {"n_neighbors": 20, "leaf_size": 50},
            {"n_neighbors": 30, "leaf_size": 50},
            {"n_neighbors": 50, "leaf_size": 50},
            {"n_neighbors": 100, "leaf_size": 50},
            {"n_neighbors": 20, "leaf_size": 100},
            {"n_neighbors": 30, "leaf_size": 100},
            {"n_neighbors": 50, "leaf_size": 100},
            {"n_neighbors": 100, "leaf_size": 100},
        ]
    if model_name == "OCSVM":
        return [{"nu": c, "kernel": "rbf"}]
    if model_name == "IF":
        return [
            {"n_estimators": 100, "contamination": c, "max_samples": 256, "max_features": 0.9, "random_state": 42},
            {"n_estimators": 200, "contamination": c, "max_samples": 256, "max_features": 0.9, "random_state": 42},
            {"n_estimators": 300, "contamination": c, "max_samples": 256, "max_features": 0.9, "random_state": 42},
        ]
    if model_name == "PCA":
        return [
            {"n_components": 0.95, "contamination": c},
            {"n_components": 0.90, "contamination": c},
            {"n_components": 0.85, "contamination": c},
            {"n_components": 0.80, "contamination": c},
        ]
    if model_name == "IF-PCA":
        out = []
        for n_comp in [0.95, 0.90, 0.85, 0.80]:
            for n_est in [100, 200, 300]:
                out.append({"n_components": n_comp, "n_estimators": n_est, "contamination": c})
        return out
    if model_name == "OCSVM-PCA":
        return [
            {"n_components": 0.95, "nu": c, "kernel": "rbf"},
            {"n_components": 0.90, "nu": c, "kernel": "rbf"},
            {"n_components": 0.85, "nu": c, "kernel": "rbf"},
            {"n_components": 0.80, "nu": c, "kernel": "rbf"},
        ]
    raise ValueError(f"unknown model: {model_name}")

def _contamination_for(model_name: str, params: Dict[str, Any], fallback: float) -> float:
    if "contamination" in params:
        return float(params["contamination"])
    model_name = normalize_model_name(model_name)
    if model_name in ("OCSVM", "OCSVM-PCA") and "nu" in params:
        return float(params["nu"])
    return float(fallback)

def fit_model(model_name: str, params: Dict[str, Any], Xtrain: np.ndarray):
    model_name = normalize_model_name(model_name)
    def _cap_max_samples(p: Dict[str, Any], n_samples: int) -> Dict[str, Any]:
        p = dict(p or {})
        ms = p.get("max_samples", None)
        if isinstance(ms, int) and n_samples > 0:
            p["max_samples"] = int(min(ms, n_samples))
        return p
    if model_name == "IF":
        p = _cap_max_samples(params, int(Xtrain.shape[0]))
        return IsolationForest(**p).fit(Xtrain)
    if model_name == "OCSVM":
        return OneClassSVM(kernel=params.get("kernel", "rbf"), gamma=params.get("gamma", "scale"), nu=params.get("nu", 0.04)).fit(Xtrain)
    if model_name == "LOF":
        return LocalOutlierFactor(
            novelty=True,
            n_neighbors=int(params.get("n_neighbors", 20)),
            leaf_size=int(params.get("leaf_size", 30)),
        ).fit(Xtrain)
    if model_name == "PCA":
        p = PCA(n_components=params.get("n_components", 0.95), random_state=42).fit(Xtrain)
        return {"pca": p}
    if model_name == "IF-PCA":
        pca = PCA(n_components=params.get("n_components", 0.95), random_state=42).fit(Xtrain)
        Z = pca.transform(Xtrain)
        base_params = {
            "n_estimators": int(params.get("n_estimators", 200)),
            "contamination": float(params.get("contamination", 0.04)),
            "max_samples": 256,
            "max_features": 0.9,
            "random_state": 42,
        }
        base_params = _cap_max_samples(base_params, int(Z.shape[0]))
        base = IsolationForest(**base_params).fit(Z)
        return {"pca": pca, "base": base}
    if model_name == "OCSVM-PCA":
        pca = PCA(n_components=params.get("n_components", 0.95), random_state=42).fit(Xtrain)
        Z = pca.transform(Xtrain)
        base = OneClassSVM(
            kernel=params.get("kernel", "rbf"),
            gamma=params.get("gamma", "scale"),
            nu=float(params.get("nu", 0.04)),
        ).fit(Z)
        return {"pca": pca, "base": base}
    raise ValueError("unknown model")

def decision_scores(model_name: str, model, Xtest: np.ndarray) -> np.ndarray:
    model_name = normalize_model_name(model_name)
    if model_name in ("IF", "OCSVM", "LOF"):
        if hasattr(model, "decision_function"):
            return -model.decision_function(Xtest)
        if hasattr(model, "score_samples"):
            return -model.score_samples(Xtest)
        return (model.predict(Xtest) == -1).astype(float)

    if model_name == "PCA":
        pca: PCA = model["pca"]
        Xhat = pca.inverse_transform(pca.transform(Xtest))
        return np.mean((Xtest - Xhat) ** 2, axis=1)

    if model_name in ("IF-PCA", "OCSVM-PCA"):
        pca: PCA = model["pca"]
        base = model["base"]
        Z = pca.transform(Xtest)
        if hasattr(base, "decision_function"):
            return -base.decision_function(Z)
        if hasattr(base, "score_samples"):
            return -base.score_samples(Z)
        return (base.predict(Z) == -1).astype(float)

    raise ValueError("unknown model")

def threshold_by_train(scores_train: np.ndarray, contamination: float) -> float:
    if scores_train is None or len(scores_train) == 0:
        return float("nan")
    c = float(contamination)
    c = min(max(c, 1e-6), 0.5)
    return float(np.nanquantile(scores_train, 1.0 - c))


def threshold_from_train(scores_train: np.ndarray, contamination: float) -> float:
    return threshold_by_train(scores_train, contamination)


def evaluate_metrics(ytrue: np.ndarray, ypred: np.ndarray, scores: np.ndarray) -> Dict[str, float]:
    try:
        roc = roc_auc_score(ytrue, scores) if len(np.unique(ytrue)) > 1 else float("nan")
    except Exception:
        roc = float("nan")
    return {
        "accuracy": float(accuracy_score(ytrue, ypred)),
        "precision": float(precision_score(ytrue, ypred, zero_division=0)),
        "recall": float(recall_score(ytrue, ypred, zero_division=0)),
        "f1": float(f1_score(ytrue, ypred, zero_division=0)),
        "roc_auc": float(roc),
    }

@app.get("/status")
def status():
    try:
        http_get(f"{COLLECTOR_URL}/docs").raise_for_status()
        http_get(f"{STORAGE_URL}/docs").raise_for_status()
        return {"ok": True, "collector": COLLECTOR_URL, "storage": STORAGE_URL}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/evaluate_once")
def evaluate_once(payload: Dict[str, Any]):
    io_id = str(payload.get("io_id"))
    size = str(payload.get("size", "70_30"))
    shift = int(payload.get("shift", 0))
    window_size = int(payload.get("window_size", 10))
    encoding = str(payload.get("encoding", "one_hot"))
    model_name = normalize_model_name(str(payload.get("model", "IF")))
    params = payload.get("params") or {}
    param_index = int(payload.get("param_index", 0))

    tr_df, te_df, collector_meta = fetch_dataset(io_id, split=size, shift=shift)
    if tr_df.empty or te_df.empty:
        raise HTTPException(400, "empty train/test split (check io_id / dataset)")

    Xtr, Xte, yte, ts, val, scaler = make_xy(tr_df, te_df, io_id=io_id, window_points=window_size, encoding=encoding)
    if Xtr.size == 0 or Xte.size == 0:
        raise HTTPException(400, "not enough rows to build features for this window_size")

    if not params:
        grid = model_grid(model_name, float(CFG.get("contamination", 0.04)))
        if not grid:
            raise HTTPException(400, f"no param grid for model={model_name}")
        if param_index < 0 or param_index >= len(grid):
            raise HTTPException(400, f"param_index out of range: 0..{len(grid)-1}")
        params = grid[param_index]

    model = fit_model(model_name, params, Xtr)
    scores_train = decision_scores(model_name, model, Xtr)
    scores_test = decision_scores(model_name, model, Xte)

    cont = float(payload.get("contamination") or _contamination_for(model_name, params, float(CFG.get("contamination", 0.04))))
    thr = threshold_from_train(scores_train, cont)
    ypred = (scores_test >= thr).astype(int)
    metrics = evaluate_metrics(yte, ypred, scores_test)

    metric_id = None
    model_id = None
    if bool(payload.get("save", False)):
        try:
            metric_payload = MetricCreate(
                run_id=payload.get("run_id"),
                io_id=io_id,
                model=model_name,
                size=size,
                shift=shift,
                window_size=window_size,
                encoding=encoding,
                params=params,
                metrics=metrics,
            ).model_dump()
            r = http_post(f"{STORAGE_URL}/metrics/create", json_payload=metric_payload)
            r.raise_for_status()
            try:
                metric_id = (r.json() or {}).get("metric_id")
            except Exception:
                metric_id = None
        except Exception as e:
            LOG.info(f"failed to save metrics to storage: {e}")

        save_model = bool(payload.get("save_model", True))
        if save_model:
            rid = payload.get("run_id")
            ts_tag = int(time.time())
            if rid is not None:
                model_id = f"run_{int(rid)}_{model_name}_{encoding}_w{window_size}_s{shift}_{ts_tag}"
            else:
                model_id = f"model_{model_name}_{encoding}_w{window_size}_s{shift}_{ts_tag}"

            try:
                out_dir = os.path.join(MODELS_DIR, model_id)
                meta = {
                    "model_id": model_id,
                    "run_id": payload.get("run_id"),
                    "metric_id": metric_id,
                    "io_id": io_id,
                    "size": size,
                    "shift": shift,
                    "window_size": window_size,
                    "encoding": encoding,
                    "model": model_name,
                    "params": params,
                    "contamination": cont,
                    "threshold": thr,
                    "collector_meta": collector_meta,
                    "created_at": dt.datetime.utcnow().isoformat(),
                }
                save_model_artifact(model_name=model_name, params=params, model=model, scaler=scaler, meta=meta, out_dir=out_dir)
                LOG.info(f"model.saved id={model_id} dir={out_dir}")
            except Exception as e:
                LOG.info(f"failed to save model artifact: {e}")

    return {
        "io_id": io_id,
        "size": size,
        "shift": shift,
        "window_size": window_size,
        "encoding": encoding,
        "model": model_name,
        "params": params,
        "contamination": cont,
        "threshold": thr,
        "saved": {"run_id": payload.get("run_id"), "metric_id": metric_id, "model_id": model_id} if bool(payload.get("save", False)) else None,
        "metrics": metrics,
        "points": [
            {
                "event_timestamp": int(t),
                "value": float(v),
                "y_true": int(yt),
                "y_pred": int(yp),
                "score": float(sc),
            }
            for t, v, yt, yp, sc in zip(ts, val, yte.tolist(), ypred.tolist(), scores_test.tolist())
        ],
    }


@app.get("/param_grid")
def get_param_grid(model: str, contamination: Optional[float] = None):

    model_n = normalize_model_name(model)
    c = float(contamination) if contamination is not None else float(CFG.get("contamination", 0.04))
    return {"model": model_n, "default_contamination": c, "params": model_grid(model_n, c)}


@app.post("/infer_once")
def infer_once(payload: Dict[str, Any]):
    io_id = str(payload.get("io_id"))
    size = str(payload.get("size", "70_30"))
    shift = int(payload.get("shift", 0))
    window_size = int(payload.get("window_size", 10))
    encoding = str(payload.get("encoding", "one_hot"))
    model_name = normalize_model_name(str(payload.get("model", "IF")))
    params = payload.get("params") or {}
    param_index = int(payload.get("param_index", 0))
    tr_df, te_df, _ = fetch_dataset(io_id, split=size, shift=shift)
    if tr_df.empty or te_df.empty:
        raise HTTPException(400, "empty train/test split (check io_id / dataset)")

    Xtr, Xte, yte, ts, val, scaler = make_xy(tr_df, te_df, io_id=io_id, window_points=window_size, encoding=encoding)
    if Xtr.size == 0 or Xte.size == 0:
        raise HTTPException(400, "not enough rows to build features for this window_size")

    if not params:
        grid = model_grid(model_name, float(CFG.get("contamination", 0.04)))
        if not grid:
            raise HTTPException(400, f"no param grid for model={model_name}")
        if param_index < 0 or param_index >= len(grid):
            raise HTTPException(400, f"param_index out of range: 0..{len(grid)-1}")
        params = grid[param_index]

    model = fit_model(model_name, params, Xtr)
    scores_train = decision_scores(model_name, model, Xtr)
    scores_test = decision_scores(model_name, model, Xte)

    cont = float(payload.get("contamination") or _contamination_for(model_name, params, float(CFG.get("contamination", 0.04))))
    thr = threshold_from_train(scores_train, cont)
    ypred = (scores_test >= thr).astype(int)
    metrics = evaluate_metrics(yte, ypred, scores_test)

    return {
        "io_id": io_id,
        "size": size,
        "shift": shift,
        "window_size": window_size,
        "encoding": encoding,
        "model": model_name,
        "params": params,
        "contamination": cont,
        "threshold": thr,
        "metrics": metrics,
        "points": [
            {"event_timestamp": int(t), "value": float(v), "y_true": int(yt), "y_pred": int(yp), "score": float(sc)}
            for t, v, yt, yp, sc in zip(ts, val, yte.tolist(), ypred.tolist(), scores_test.tolist())
        ],
    }

def _model_id(meta: Dict[str, Any]) -> str:
    return f"{meta['io_id']}_{meta['model']}_{meta['size']}_{meta['encoding']}_w{meta['window_size']}_s{meta['shift']}_{int(time.time())}"

@app.post("/models/train")
def train_and_save(payload: Dict[str, Any]):
    io_id = str(payload.get("io_id"))
    size = str(payload.get("size", "70_30"))
    shift = int(payload.get("shift", 0))
    window_size = int(payload.get("window_size", 10))
    encoding = str(payload.get("encoding", "one_hot"))
    model_name = normalize_model_name(str(payload.get("model", "IF")))
    params = payload.get("params") or {}
    tr_df, te_df, _ = fetch_dataset(io_id, split=size, shift=shift)

    Xtr, Xte, yte, ts, val, scaler = make_xy(tr_df, te_df, io_id=io_id, window_points=window_size, encoding=encoding)
    if Xtr.size == 0:
        raise HTTPException(400, "not enough rows to build train features")

    if not params:
        params = model_grid(model_name, float(CFG.get("contamination", 0.04)))[0]

    model = fit_model(model_name, params, Xtr)
    scores_train = decision_scores(model_name, model, Xtr)
    scores_test = decision_scores(model_name, model, Xte)
    cont = float(payload.get("contamination") or _contamination_for(model_name, params, float(CFG.get("contamination", 0.04))))
    thr = threshold_from_train(scores_train, cont)
    ypred = (scores_test >= thr).astype(int)
    metrics = evaluate_metrics(yte, ypred, scores_test)

    meta = {
        "io_id": io_id,
        "size": size,
        "shift": shift,
        "window_size": window_size,
        "encoding": encoding,
        "model": model_name,
        "params": params,
        "contamination": cont,
        "created_at": int(time.time()),
        "threshold": thr,
        "metrics_on_test": metrics,
    }
    mid = _model_id(meta)
    out_dir = os.path.join(MODELS_DIR, mid)
    os.makedirs(out_dir, exist_ok=True)

    joblib.dump({"model_name": model_name, "model": model, "scaler": scaler, "meta": meta}, os.path.join(out_dir, "bundle.joblib"))
    with open(os.path.join(out_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    LOG.info(f"model.saved id={mid} -> {out_dir}")
    return {"model_id": mid, "meta": meta}

@app.get("/models/list")
def list_models(limit: int = 200):
    if not os.path.exists(MODELS_DIR):
        return []
    items = []
    for name in sorted(os.listdir(MODELS_DIR), reverse=True)[: int(limit)]:
        meta_path = os.path.join(MODELS_DIR, name, "meta.json")
        if os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                meta = None
        else:
            meta = None
        items.append({"model_id": name, "meta": meta})
    return items

@app.get("/models/{model_id}/summary")
def model_summary(model_id: str):
    meta_path = os.path.join(MODELS_DIR, model_id, "meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "model not found")
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    return meta

@app.post("/models/infer")
def infer_saved(payload: Dict[str, Any]):
    model_id = str(payload.get("model_id"))
    bundle_path = os.path.join(MODELS_DIR, model_id, "bundle.joblib")
    if not os.path.exists(bundle_path):
        raise HTTPException(404, "model not found")

    bundle = joblib.load(bundle_path)
    meta = bundle["meta"]
    model_name = bundle["model_name"]
    model = bundle["model"]
    scaler = bundle["scaler"]

    size = str(payload.get("size", meta.get("size", "70_30")))
    shift = int(payload.get("shift", meta.get("shift", 0)))
    te_df = fetch_split(meta["io_id"], split=size, shift=shift, part="test")
    if te_df.empty:
        raise HTTPException(400, "empty test split")

    Xte_df, _ = prepare_features(
        te_df,
        io_id=meta["io_id"],
        hour_min=meta["encoding"] in ["sin_cos", "sin_cos_cyclic"],
        cyclic=meta["encoding"] in ["cyclic", "sin_cos_cyclic"],
        window_points=int(meta["window_size"]),
    )
    if Xte_df.empty:
        raise HTTPException(400, "not enough rows to build test features")

    te_sorted = te_df.copy().sort_values("event_timestamp").reset_index(drop=True)
    n = len(Xte_df)
    yte = te_sorted["anomaly"].fillna(0).astype(int).iloc[:n].to_numpy()
    ts  = te_sorted["event_timestamp"].iloc[:n].astype(int).to_list()
    val = te_sorted["value"].astype(float).iloc[:n].to_list()

    Xte = scaler.transform(Xte_df.values)
    scores = decision_scores(model_name, model, Xte)
    cont = float(meta.get("contamination", 0.04))
    thr = float(meta.get("threshold", threshold_from_train(scores, cont)))
    ypred = (scores >= thr).astype(int)
    metrics = evaluate_metrics(yte, ypred, scores)

    return {
        "model_id": model_id,
        "threshold": thr,
        "metrics": metrics,
        "points": [
            {"event_timestamp": int(t), "value": float(v), "y_true": int(yt), "y_pred": int(yp), "score": float(sc)}
            for t, v, yt, yp, sc in zip(ts, val, yte.tolist(), ypred.tolist(), scores.tolist())
        ],
    }
