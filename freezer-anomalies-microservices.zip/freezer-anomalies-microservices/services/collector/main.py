import os
import yaml
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from typing import Tuple, List, Set
from services_shared.utils import setup_logger

DATA_DIR = os.getenv("DATA_DIR", "/data")
SHIFT_STEP_DAYS = int(os.getenv("SHIFT_STEP_DAYS", "20"))

COLLECTOR_RESAMPLE_RULE = os.getenv("COLLECTOR_RESAMPLE_RULE", "1min")

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${DATA_DIR:/data}", DATA_DIR)
    return yaml.safe_load(raw)

cfg = load_config()
LOGS_DIR = os.getenv("LOGS_DIR") or os.getenv("LOG_DIR") or "/logs"
logger = setup_logger("collector", logs_dir=LOGS_DIR)

app = FastAPI(title="Collector Service", version="2.0")

_CACHE = {}

def read_csv(kind: str) -> pd.DataFrame:
    if kind in _CACHE:
        return _CACHE[kind]

    fname = cfg["files"][kind]
    fpath = os.path.join(cfg["data_path"], fname)
    if not os.path.exists(fpath):
        raise HTTPException(
            status_code=404,
            detail=f"Файл {fpath} не найден. Поместите CSV в {cfg['data_path']}."
        )
    df = pd.read_csv(fpath)
    df.columns = [c.strip().lower() for c in df.columns]

    for c in ["value_min", "value_max"]:
        if c in df.columns:
            df = df.drop(columns=[c])

    for col in ["event_timestamp", "io_id", "value"]:
        if col not in df.columns:
            raise HTTPException(400, f"{kind} missing column: {col}")

    df["event_timestamp"] = df["event_timestamp"].astype(int)
    df["io_id"] = df["io_id"].astype(str)
    df["value"] = df["value"].astype(float)

    if kind == "annotated":
        if "anomaly" not in df.columns:
            df["anomaly"] = 0
        df["anomaly"] = df["anomaly"].astype(int)

    _CACHE[kind] = df
    return df

def _with_date(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["date"] = pd.to_datetime(out["event_timestamp"], unit="s", utc=True).dt.date
    return out


def _resample(df: pd.DataFrame, labeled: bool, rule: str) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    rule = str(rule or "").strip().lower()
    if rule in ("", "none", "raw"):
        return df

    out = df.copy().sort_values("event_timestamp")
    dt = pd.to_datetime(out["event_timestamp"].astype(int), unit="s", utc=True)
    out = out.assign(_dt=dt).set_index("_dt")

    agg = {"value": "mean"}
    if labeled:
        if "anomaly" not in out.columns:
            out["anomaly"] = 0
        agg["anomaly"] = "max"

    res = out.resample(rule).agg(agg).dropna(subset=["value"]).reset_index()
    res.rename(columns={"_dt": "datetime"}, inplace=True)
    res["event_timestamp"] = (res["datetime"].astype("int64") // 10**9).astype(int)
    res["io_id"] = out["io_id"].iloc[0]
    if labeled:
        res["anomaly"] = res["anomaly"].fillna(0).astype(int)
        return res[["event_timestamp", "io_id", "value", "anomaly"]]
    return res[["event_timestamp", "io_id", "value"]]

def _parse_split_ratio(split: str) -> Tuple[int, int]:
    try:
        a, b = split.split("_")
        a_i, b_i = int(a), int(b)
        if a_i <= 0 or b_i <= 0:
            raise ValueError()
        return a_i, b_i
    except Exception:
        raise HTTPException(400, f"Bad split format: {split}. Expected like '70_30'")

def _day_sets(io_id: str, split: str, shift: int) -> Tuple[Set, Set, List, int, int, int, int, List]:

    a, b = _parse_split_ratio(split)

    ann = _with_date(read_csv("annotated"))
    ann = ann[ann["io_id"] == str(io_id)]
    if ann.empty:
        raise HTTPException(404, f"io_id={io_id} not found in annotated_dataset.csv")

    dates = sorted(ann["date"].unique().tolist())
    n_days = len(dates)
    if n_days < 2:
        raise HTTPException(400, f"Not enough unique days for io_id={io_id}: {n_days}")

    total = a + b
    train_len = int(round(n_days * (a / total)))
    train_len = max(1, min(train_len, n_days - 1))
    test_len = n_days - train_len

    shift_idx = int(shift)
    if shift_idx < 0:
        raise HTTPException(400, "shift must be >= 0")
    if shift_idx > 4:
        raise HTTPException(400, "shift must be in [0, 4] (0->0d,1->20d,2->40d,3->60d,4->80d)")

    shift_days = shift_idx * SHIFT_STEP_DAYS
    start = int(shift_days) % n_days
    ordered = [dates[(start + i) % n_days] for i in range(n_days)]

    train_days_set = set(ordered[:train_len])
    test_days_set = set(ordered[train_len:])
    return train_days_set, test_days_set, dates, train_len, test_len, start, shift_days, ordered

@app.get("/io_ids")
def list_io_ids():
    ann = read_csv("annotated")
    ids = sorted(ann["io_id"].astype(str).unique().tolist())
    logger.info(f"/io_ids count={len(ids)}")
    return ids

@app.get("/split")
def get_split(
    io_id: str,
    split: str = "70_30",
    shift: int = 0,
):

    train_days_set, test_days_set, dates, train_len, test_len, start, shift_days, ordered = _day_sets(io_id, split, shift)

    freezer = _with_date(read_csv("freezer"))
    ann = _with_date(read_csv("annotated"))

    freezer = freezer[freezer["io_id"] == str(io_id)]
    ann = ann[ann["io_id"] == str(io_id)]

    train_df = (
        freezer[freezer["date"].isin(train_days_set)]
        .drop(columns=["date"])
        .sort_values("event_timestamp")
    )
    test_df = (
        ann[ann["date"].isin(test_days_set)]
        .drop(columns=["date"])
        .sort_values("event_timestamp")
    )

    train_df = _resample(train_df, labeled=False, rule=COLLECTOR_RESAMPLE_RULE)
    test_df = _resample(test_df, labeled=True, rule=COLLECTOR_RESAMPLE_RULE)

    def _range_info(df: pd.DataFrame) -> dict:
        if df is None or df.empty:
            return {"rows": 0}
        ts0 = int(df["event_timestamp"].min())
        ts1 = int(df["event_timestamp"].max())
        d0 = pd.to_datetime(ts0, unit="s", utc=True).date().isoformat()
        d1 = pd.to_datetime(ts1, unit="s", utc=True).date().isoformat()
        return {"rows": int(len(df)), "ts_min": ts0, "ts_max": ts1, "date_min": d0, "date_max": d1}

    train_range = _range_info(train_df)
    test_range = _range_info(test_df)

    logger.info(
        f"/split io_id={io_id} split={split} shift_idx={int(shift)} shift_days={shift_days} start_idx={start} "
        f"unique_days={len(dates)} train_days={train_len} test_days={test_len} "
        f"train_rows={len(train_df)} test_rows={len(test_df)} resample={COLLECTOR_RESAMPLE_RULE}"
    )

    return {
        "meta": {
            "io_id": io_id,
            "split": split,
            "shift_index": int(shift),
            "shift_days": int(shift_days),
            "start_day": str(dates[start]),
            "unique_days": len(dates),
            "train_days": int(train_len),
            "test_days": int(test_len),
            "dates_first_last": [str(dates[0]), str(dates[-1])],
            "train_span": [str(ordered[0]), str(ordered[train_len - 1])],
            "test_span": [str(ordered[train_len]), str(ordered[-1])],
            "train_range": train_range,
            "test_range": test_range,
            "resample_rule": COLLECTOR_RESAMPLE_RULE,
        },
        "train": train_df.to_dict(orient="records"),
        "test": test_df.to_dict(orient="records"),
    }
