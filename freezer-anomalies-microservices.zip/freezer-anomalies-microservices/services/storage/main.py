import os
import yaml
import json
import datetime as dt
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine, text
from services_shared.utils import setup_logger
from services_shared.schemas import RunCreate, MetricCreate

DATA_DIR = os.getenv("DATA_DIR", "/data")
ARTIFACTS_DIR = os.getenv("ARTIFACTS_DIR", "/artifacts")

_RUNS_DIR = os.path.join(ARTIFACTS_DIR, "runs")
_METRICS_DIR = os.path.join(ARTIFACTS_DIR, "metrics")
os.makedirs(_RUNS_DIR, exist_ok=True)
os.makedirs(_METRICS_DIR, exist_ok=True)

def load_config() -> dict:
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${DATA_DIR:/data}", DATA_DIR)
    return yaml.safe_load(raw)

cfg = load_config()
logger = setup_logger("storage", os.getenv("LOGS_DIR", "/logs"))

engine = create_engine(f"sqlite:///{cfg['db_path']}", future=True)

# ---- DB init ----
with engine.begin() as conn:
    conn.exec_driver_sql("""
    CREATE TABLE IF NOT EXISTS runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT,
        config_json TEXT
    );
    """)
    conn.exec_driver_sql("""
    CREATE TABLE IF NOT EXISTS metrics_single (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT,
        run_id INTEGER,
        io_id TEXT,
        model TEXT,
        size TEXT,
        shift INTEGER,
        window_size INTEGER,
        encoding TEXT,
        params_json TEXT,
        metrics_json TEXT
    );
    """)

    conn.exec_driver_sql("""
    CREATE TABLE IF NOT EXISTS metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER,
        io_id TEXT,
        model TEXT,
        size TEXT,
        window_size INTEGER,
        encoding TEXT,
        metric_means TEXT,
        metric_iqrs TEXT,
        best_params TEXT
    );
    """)

app = FastAPI(title="Storage Service", version="1.1")

def _json_loads_maybe(s: Any) -> Any:
    if s is None:
        return None
    if isinstance(s, (dict, list)):
        return s
    if isinstance(s, str):
        try:
            return json.loads(s)
        except Exception:
            return s
    return s

@app.post("/runs/create")
def create_run(payload: RunCreate):
    config_blob = {
        "note": payload.note,
        "config": payload.config_json,
    }
    with engine.begin() as conn:
        conn.execute(
            text("INSERT INTO runs(created_at, config_json) VALUES(:ts, :cfg)"),
            dict(ts=dt.datetime.utcnow().isoformat(), cfg=json.dumps(config_blob, ensure_ascii=False))
        )
        run_id = conn.execute(text("SELECT last_insert_rowid()")).scalar_one()
    logger.info(f"runs.create id={run_id} note={payload.note}")

    try:
        out_path = os.path.join(_RUNS_DIR, f"run_{int(run_id)}.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump({"run_id": int(run_id), "created_at": dt.datetime.utcnow().isoformat(), **config_blob}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.info(f"runs.create: failed to write artifact json: {e}")

    return {"run_id": int(run_id)}

@app.get("/runs")
def list_runs(limit: int = 50, offset: int = 0):
    with engine.begin() as conn:
        rows = conn.execute(
            text("SELECT id, created_at, config_json FROM runs ORDER BY id DESC LIMIT :lim OFFSET :off"),
            dict(lim=int(limit), off=int(offset))
        ).mappings().all()
    out = []
    for r in rows:
        rr = dict(r)
        rr["config_json"] = _json_loads_maybe(rr.get("config_json"))
        out.append(rr)
    return out

@app.get("/runs/{run_id}")
def get_run(run_id: int):
    with engine.begin() as conn:
        row = conn.execute(
            text("SELECT id, created_at, config_json FROM runs WHERE id=:rid"),
            dict(rid=int(run_id))
        ).mappings().first()
    if not row:
        raise HTTPException(404, "run not found")
    out = dict(row)
    out["config_json"] = _json_loads_maybe(out.get("config_json"))
    return out

@app.delete("/runs/{run_id}")
def delete_run(run_id: int):
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM metrics WHERE run_id=:rid"), dict(rid=int(run_id)))
        res = conn.execute(text("DELETE FROM runs WHERE id=:rid"), dict(rid=int(run_id)))
    logger.info(f"runs.delete id={run_id}")
    return {"deleted": True}

@app.get("/runs/latest")
def latest_run():
    with engine.begin() as conn:
        row = conn.execute(
            text("SELECT id, created_at, config_json FROM runs ORDER BY id DESC LIMIT 1")
        ).mappings().first()
    if not row:
        raise HTTPException(404, "no runs yet")
    out = dict(row)
    out["config_json"] = _json_loads_maybe(out.get("config_json"))
    return out

@app.post("/metrics/create")
def create_metric(payload: MetricCreate):
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO metrics_single(created_at, run_id, io_id, model, size, shift, window_size, encoding, params_json, metrics_json)
                VALUES(:ts,:run_id,:io_id,:model,:size,:shift,:ws,:enc,:params,:metrics)
                """
            ),
            dict(
                ts=dt.datetime.utcnow().isoformat(),
                run_id=int(payload.run_id) if payload.run_id is not None else None,
                io_id=payload.io_id,
                model=payload.model,
                size=payload.size,
                shift=int(payload.shift),
                ws=int(payload.window_size),
                enc=payload.encoding,
                params=json.dumps(payload.params or {}, ensure_ascii=False),
                metrics=json.dumps(payload.metrics or {}, ensure_ascii=False),
            ),
        )
        metric_id = conn.execute(text("SELECT last_insert_rowid()")).scalar_one()
    logger.info(
        f"metrics_single.create run_id={payload.run_id} io_id={payload.io_id} model={payload.model} size={payload.size} shift={payload.shift} ws={payload.window_size} enc={payload.encoding}"
    )

    try:
        out = {
            "metric_id": int(metric_id),
            "created_at": dt.datetime.utcnow().isoformat(),
            "run_id": int(payload.run_id) if payload.run_id is not None else None,
            "io_id": payload.io_id,
            "model": payload.model,
            "size": payload.size,
            "shift": int(payload.shift),
            "window_size": int(payload.window_size),
            "encoding": payload.encoding,
            "params": payload.params or {},
            "metrics": payload.metrics or {},
        }
        fname = f"metric_{int(metric_id)}_run_{int(payload.run_id) if payload.run_id is not None else 'none'}.json"
        out_path = os.path.join(_METRICS_DIR, fname)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.info(f"metrics_single.create: failed to write artifact json: {e}")

    return {"status": "ok", "metric_id": int(metric_id)}

@app.get("/metrics")
def list_metrics(run_id: Optional[int] = None, limit: int = 200, offset: int = 0):
    q = "SELECT * FROM metrics_single"
    params: Dict[str, Any] = {"lim": int(limit), "off": int(offset)}
    if run_id is not None:
        q += " WHERE run_id=:rid"
        params["rid"] = int(run_id)
    q += " ORDER BY id DESC LIMIT :lim OFFSET :off"
    with engine.begin() as conn:
        rows = conn.execute(text(q), params).mappings().all()
    out = []
    for r in rows:
        rr = dict(r)
        rr["params_json"] = _json_loads_maybe(rr.get("params_json"))
        rr["metrics_json"] = _json_loads_maybe(rr.get("metrics_json"))
        out.append(rr)
    return out

@app.get("/metrics/{metric_id}")
def get_metric(metric_id: int):
    with engine.begin() as conn:
        row = conn.execute(text("SELECT * FROM metrics_single WHERE id=:mid"), dict(mid=int(metric_id))).mappings().first()
    if not row:
        raise HTTPException(404, "metric not found")
    rr = dict(row)
    rr["params_json"] = _json_loads_maybe(rr.get("params_json"))
    rr["metrics_json"] = _json_loads_maybe(rr.get("metrics_json"))
    return rr

@app.delete("/metrics/{metric_id}")
def delete_metric(metric_id: int):
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM metrics_single WHERE id=:mid"), dict(mid=int(metric_id)))
    logger.info(f"metrics.delete id={metric_id}")
    return {"deleted": True}

@app.get("/metrics/by_run/{run_id}")
def metrics_by_run(run_id: int):
    with engine.begin() as conn:
        rows = conn.execute(text("SELECT * FROM metrics_single WHERE run_id=:rid"), dict(rid=int(run_id))).mappings().all()
    out = []
    for r in rows:
        rr = dict(r)
        rr["params_json"] = _json_loads_maybe(rr.get("params_json"))
        rr["metrics_json"] = _json_loads_maybe(rr.get("metrics_json"))
        out.append(rr)
    return out
