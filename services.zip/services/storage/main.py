import os, yaml, json, datetime as dt
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from services_shared.utils import setup_logger

DATA_DIR = os.getenv("DATA_DIR", "/data")

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${DATA_DIR:/data}", DATA_DIR)
    return yaml.safe_load(raw)

cfg = load_config()
logger = setup_logger("storage", os.getenv("LOGS_DIR", "/logs"))

engine = create_engine(f"sqlite:///{cfg['db_path']}", future=True)

with engine.begin() as conn:
    conn.exec_driver_sql("""
    CREATE TABLE IF NOT EXISTS runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT,
        config_json TEXT
    );
    """)
    conn.exec_driver_sql("""
    CREATE TABLE IF NOT EXISTS metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER,
        io_id TEXT,
        model TEXT,
        size TEXT,
        window_size INTEGER,
        encoding TEXT,
        metric_means TEXT,
        metric_iqrs TEXT,
        best_params TEXT
    );
    """)

app = FastAPI(title="Storage Service", version="1.0")

class RunCreate(BaseModel):
    config_json: Dict[str, Any]

class MetricCreate(BaseModel):
    run_id: int
    io_id: str
    model: str
    size: str
    window_size: int
    encoding: str
    metric_means: Dict[str, float]
    metric_iqrs: Dict[str, float]
    best_params: Dict[str, Any] | None = None

@app.post("/runs/create")
def create_run(payload: RunCreate):
    with engine.begin() as conn:
        conn.execute(
            text("INSERT INTO runs(created_at, config_json) VALUES(:ts, :cfg)"),
            dict(ts=dt.datetime.utcnow().isoformat(), cfg=json.dumps(payload.config_json))
        )
        run_id = conn.execute(text("SELECT last_insert_rowid()")).scalar_one()
    logger.info(f"new run_id={run_id}")
    return {"run_id": int(run_id)}

@app.post("/metrics/create")
def create_metric(payload: MetricCreate):
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO metrics(run_id, io_id, model, size, window_size, encoding, metric_means, metric_iqrs, best_params)
            VALUES(:run_id,:io_id,:model,:size,:ws,:enc,:means,:iqrs,:best)
        """),
        dict(run_id=payload.run_id, io_id=payload.io_id, model=payload.model, size=payload.size,
             ws=payload.window_size, enc=payload.encoding,
             means=json.dumps(payload.metric_means), iqrs=json.dumps(payload.metric_iqrs),
             best=json.dumps(payload.best_params) if payload.best_params is not None else None))
    return {"status":"ok"}

@app.get("/metrics/by_run/{run_id}")
def metrics_by_run(run_id: int):
    with engine.begin() as conn:
        rows = conn.execute(text("SELECT * FROM metrics WHERE run_id=:rid"), dict(rid=run_id)).mappings().all()
    return [dict(r) for r in rows]

@app.get("/runs/latest")
def latest_run():
    with engine.begin() as conn:
        row = conn.execute(text("SELECT id, created_at, config_json FROM runs ORDER BY id DESC LIMIT 1")).mappings().first()
    if not row:
        raise HTTPException(404, "no runs yet")
    return dict(row)
