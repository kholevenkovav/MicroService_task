import json, os, yaml, requests, joblib
import numpy as np, pandas as pd
from fastapi import FastAPI, HTTPException
from typing import Dict, Any, List, Tuple
from services_shared.schemas import TrainRequest, TrainConfig, MetricRow
from services_shared.utils import setup_logger
from pipeline import (
    interpolate_per_minute, prepare_features, rolling_splits, parse_size, run_estimator
)
from scipy.stats import iqr
from sklearn.preprocessing import RobustScaler

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${MODELS_DIR:/models}", os.getenv("MODELS_DIR","/models"))
    return yaml.safe_load(raw)

cfg = load_config()
logger = setup_logger("ml", os.getenv("LOGS_DIR","/logs"))
COLLECTOR = cfg["collector_url"]
STORAGE = cfg["storage_url"]
MODELS_DIR = cfg["models_dir"]
os.makedirs(MODELS_DIR, exist_ok=True)

app = FastAPI(title="ML Service", version="1.0")

def fetch_batch(io_id: str, start_ts: int, end_ts: int, annotated: bool):
    url = f"{COLLECTOR}/batch"
    r = requests.get(url, params=dict(io_id=io_id, start_ts=start_ts, end_ts=end_ts, annotated=annotated, limit=500000))
    if r.status_code != 200:
        raise HTTPException(r.status_code, f"collector error: {r.text}")
    return pd.DataFrame(r.json())

def aggregate_metrics(hist: Dict[str, List[float]]):
    means = {k: float(np.mean(v)) for k,v in hist.items() if v}
    iqrs  = {k: float(iqr(v))   for k,v in hist.items() if v}
    return means, iqrs

def model_grid(model: str, contamination: float):
    if model == "IF":
        return [dict(n_estimators=n, contamination=contamination, random_state=42) for n in [100,200,300]]
    if model == "OCSVM":
        return [dict(nu=contamination, kernel='rbf'), dict(nu=contamination, kernel='linear')]
    if model == "DBSCAN":
        return [dict(eps=e, min_samples=m) for e in [0.5,1.0,1.5] for m in [5,10]]
    if model == "LOF":
        return [dict(n_neighbors=n) for n in [20,35,50]]
    if model == "PCA":
        return [dict(n_components=p) for p in [0.80,0.85,0.90,0.95]]
    if model == "IF-PCA":
        return [dict(n_components=p, n_estimators=n, contamination=contamination) for p in [0.80,0.90,0.95] for n in [100,200]]
    if model == "OCSVM-PCA":
        return [dict(n_components=p, nu=contamination, kernel='rbf') for p in [0.80,0.90,0.95]]
    raise ValueError("unknown model")

@app.post("/train_evaluate")
def train_evaluate(req: TrainRequest):
    if not req.io_ids:
        ann = fetch_batch(io_id=None, start_ts=None, end_ts=None, annotated=True)
        io_ids = sorted(map(str, ann["io_id"].astype(str).unique()))
    else:
        io_ids = list(map(str, req.io_ids))

    run_resp = requests.post(f"{STORAGE}/runs/create", json={"config_json": req.config.model_dump()})
    if run_resp.status_code != 200:
        raise HTTPException(500, f"storage error: {run_resp.text}")
    run_id = run_resp.json()["run_id"]

    results_to_store: List[MetricRow] = []

    for io_id in io_ids:
        logger.info(f"IO {io_id}")
        fr = fetch_batch(io_id=io_id, start_ts=None, end_ts=None, annotated=False)
        ann = fetch_batch(io_id=io_id, start_ts=None, end_ts=None, annotated=True)
        fr = interpolate_per_minute(fr)
        ann = interpolate_per_minute(ann)

        for encoding in req.config.time_encodings:
            for window_size in req.config.window_sizes:
                for size in req.config.splits:
                    tr_days, te_days = parse_size(size)
                    for model in req.config.models:
                        grid = model_grid(model, req.config.contamination)
                        per_grid_hist = [dict(accuracy=[], precision=[], recall=[], f1=[], roc_auc=[]) for _ in grid]
                        for sh in range(req.config.shifts):
                            train_ranges, test_ranges = rolling_splits(tr_days, te_days, sh)
                            train_df = pd.concat([fr[(fr["event_timestamp"]>=s)&(fr["event_timestamp"]<e)] for s,e in train_ranges], ignore_index=True)
                            test_df  = pd.concat([ann[(ann["event_timestamp"]>=s)&(ann["event_timestamp"]<e)] for s,e in test_ranges], ignore_index=True)
                            if train_df.empty or test_df.empty: 
                                continue
                            Xtr, _ = prepare_features(train_df, io_id, encoding, window_points=window_size)
                            Xte, dt = prepare_features(test_df, io_id, encoding, window_points=window_size)
                            if len(Xtr)==0 or len(Xte)==0: 
                                continue
                            idx = Xte.index
                            yte = test_df.loc[idx, "anomaly"].astype(int).values
                            scaler = RobustScaler()
                            Xtr_s = scaler.fit_transform(Xtr.values)
                            Xte_s = scaler.transform(Xte.values)
                            for gi, p in enumerate(grid):
                                metrics, preds = run_estimator(Xtr_s, Xte_s, yte, model_name=model, params=p, contamination=req.config.contamination)
                                if not metrics: continue
                                for k in per_grid_hist[gi].keys():
                                    per_grid_hist[gi][k].append(float(metrics[k]))
                        best_idx, best_mean = None, -1.0
                        best_means, best_iqrs = {}, {}

                        for gi, hist in enumerate(per_grid_hist):
                            if len(hist["roc_auc"]) == 0:
                                continue
                            means, iqrs = aggregate_metrics(hist)
                            if means.get("roc_auc", -1) > best_mean:
                                best_idx = gi
                                best_mean = means["roc_auc"]
                                best_means, best_iqrs = means, iqrs

                        if best_idx is None:
                            continue

                        best_params = grid[best_idx]

                        row = MetricRow(
                            io_id=io_id, model=model, size=size, window_size=window_size, encoding=encoding,
                            metric_means=best_means, metric_iqrs=best_iqrs, best_params=best_params
                        )

                        requests.post(f"{STORAGE}/metrics/create", json={
                            "run_id": run_id, **row.model_dump()
                        })
                        results_to_store.append(row)

    return {"run_id": run_id, "saved": len(results_to_store)}

@app.get("/status")
def status():
    return {"ok": True}
