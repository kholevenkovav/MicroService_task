import os, json, numpy as np, pandas as pd
from typing import Tuple, Dict, Any, List
from sklearn.preprocessing import RobustScaler
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.cluster import DBSCAN
from sklearn.neighbors import LocalOutlierFactor
from sklearn.decomposition import PCA
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, roc_auc_score
from scipy.stats import iqr

def interpolate_per_minute(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty: return df
    df = df.copy()
    df["event_timestamp"] = (df["event_timestamp"] // 60) * 60

    current_time, shift = None, 0
    for i in range(len(df)):
        ts = df.iloc[i]["event_timestamp"]
        if ts == current_time:
            shift += 60
            df.iloc[i, df.columns.get_loc("event_timestamp")] = current_time + shift
        else:
            current_time, shift = ts, 0
    min_ts, max_ts = df["event_timestamp"].min(), df["event_timestamp"].max()
    full = pd.DataFrame({"event_timestamp": np.arange(min_ts, max_ts + 60, 60)})
    out = full.merge(df, on="event_timestamp", how="left").set_index("event_timestamp")
    out = out.infer_objects(copy=False)
    out = out.interpolate(method="index", limit_direction="both")
    if "io_id" in out.columns:
        out["io_id"] = out["io_id"].ffill().bfill()
    out.reset_index(inplace=True)
    return out

def create_time_features(df: pd.DataFrame, cyclic_points: int = 240, hour_min: bool = False, cyclic: bool = False):
    df = df.copy()
    df["datetime"] = pd.to_datetime(df["event_timestamp"], unit="s")
    df["hour"] = df["datetime"].dt.hour
    df["minute"] = df["datetime"].dt.minute

    if not hour_min and not cyclic:
        hour_features = pd.get_dummies(df["hour"].astype("category"), prefix="hour", dtype=float)
        minute_features = pd.get_dummies(df["minute"].astype("category"), prefix="minute", dtype=float)
        return pd.concat([hour_features, minute_features], axis=1), df["datetime"].copy()

    cols = []
    if hour_min:
        df["hour_sin"] = np.sin(2*np.pi*df["hour"]/24)
        df["hour_cos"] = np.cos(2*np.pi*df["hour"]/24)
        df["minute_sin"] = np.sin(2*np.pi*df["minute"]/60)
        df["minute_cos"] = np.cos(2*np.pi*df["minute"]/60)
        cols += ["hour_sin","hour_cos","minute_sin","minute_cos"]
    if cyclic:
        window = np.arange(len(df)) % cyclic_points
        df["window_sin"] = np.sin(2*np.pi*window/cyclic_points)
        df["window_cos"] = np.cos(2*np.pi*window/cyclic_points)
        cols += ["window_sin","window_cos"]
    return df[cols], df["datetime"].copy()

def sliding_window_features(df: pd.DataFrame, window_points: int, label: str):
    feats = []
    for i in range(len(df) - window_points + 1):
        window = df["value"].iloc[i:i+window_points]
        feats.append([
            np.mean(window), np.std(window), np.min(window), np.max(window), np.median(window),
            np.var(window), window.iloc[-1]-window.iloc[0], np.percentile(window,25), np.percentile(window,75)
        ])
    columns = [f"{name}_{label}" for name in ["mean","std","min","max","median","var","trend","q25","q75"]]
    X = pd.DataFrame(feats, columns=columns)
    X.index = df.index[:len(X)]
    return X

def prepare_features(df: pd.DataFrame, io_id: str, encoding: str, window_points: int):
    cyclic_points = 244 if str(io_id).startswith("62") else 255
    hour_min = encoding in ["sin_cos","sin_cos_cyclic"]
    cyclic = encoding in ["cyclic","sin_cos_cyclic"]
    tfeats, dt = create_time_features(df, cyclic_points=cyclic_points, hour_min=hour_min, cyclic=cyclic)
    sw = sliding_window_features(df, window_points, label=f"{window_points}m")
    tfeats = tfeats.iloc[:len(df)-window_points+1].copy()
    X = pd.concat([sw, tfeats], axis=1)
    return X, dt

def pca_reconstruction(X_train, X_test, y_test, n_components=0.95, contamination=0.04):
    pca = PCA(n_components=n_components, random_state=42)
    Xtr = pca.fit_transform(X_train)
    Xtr_rec = pca.inverse_transform(Xtr)
    err_tr = np.sqrt(np.sum((X_train - Xtr_rec)**2, axis=1))
    thr = np.percentile(err_tr, 100*(1-contamination))
    Xte = pca.transform(X_test)
    Xte_rec = pca.inverse_transform(Xte)
    err_te = np.sqrt(np.sum((X_test - Xte_rec)**2, axis=1))
    preds = (err_te > thr).astype(int)
    scores = err_te
    return metrics_from(y_test, preds, scores), preds

def pca_base(X_train, X_test, y_test, base="IF", n_components=0.95, **kwargs):
    pca = PCA(n_components=n_components, random_state=42)
    Xtr = pca.fit_transform(X_train)
    Xte = pca.transform(X_test)
    if base == "IF":
        model = IsolationForest(
            n_estimators=kwargs.get("n_estimators", 200),
            contamination=kwargs.get("contamination", 0.04),
            max_samples=kwargs.get("max_samples", 256),
            max_features=kwargs.get("max_features", 0.9),
            random_state=42
        )
    elif base == "OCSVM":
        model = OneClassSVM(nu=kwargs.get("nu", 0.04), kernel=kwargs.get("kernel","rbf"))
    else:
        raise ValueError("unknown base")
    model.fit(Xtr)
    preds = np.where(model.predict(Xte) == -1, 1, 0)
    scores = -model.decision_function(Xte)
    return metrics_from(y_test, preds, scores), preds

def run_estimator(X_train, X_test, y_test, model_name: str, params: Dict[str,Any], contamination: float):
    if model_name == "PCA":
        return pca_reconstruction(X_train, X_test, y_test,
                                  n_components=params.get("n_components", 0.95),
                                  contamination=contamination)
    if model_name == "IF-PCA":
        return pca_base(X_train, X_test, y_test, base="IF", **params)
    if model_name == "OCSVM-PCA":
        return pca_base(X_train, X_test, y_test, base="OCSVM", **params)
    if model_name == "IsolationForest" or model_name == "IF":
        model = IsolationForest(**params)
        model.fit(X_train)
        preds = np.where(model.predict(X_test) == -1, 1, 0)
        scores = -model.decision_function(X_test)
        return metrics_from(y_test, preds, scores), preds
    if model_name == "OneClassSVM" or model_name == "OCSVM":
        model = OneClassSVM(**params)
        model.fit(X_train)
        preds = np.where(model.predict(X_test) == -1, 1, 0)
        scores = -model.decision_function(X_test)
        return metrics_from(y_test, preds, scores), preds
    if model_name == "LOF":
        model = LocalOutlierFactor(novelty=True, contamination=contamination, **params)
        model.fit(X_train)
        preds = np.where(model.predict(X_test) == -1, 1, 0)
        scores = -model.decision_function(X_test)
        return metrics_from(y_test, preds, scores), preds
    raise ValueError("Unknown model_name")

def metrics_from(y_true, preds, scores):
    return dict(
        accuracy=accuracy_score(y_true, preds),
        precision=precision_score(y_true, preds, zero_division=0),
        recall=recall_score(y_true, preds, zero_division=0),
        f1=f1_score(y_true, preds, zero_division=0),
        roc_auc=roc_auc_score(y_true, scores)
    )

def rolling_splits(train_days: int, test_days: int, shift_idx: int):
    start_total = pd.to_datetime('2023-12-31')
    total_days = 100
    shift_days = shift_idx * 20
    start_train_offset = shift_days % total_days
    end_train_offset = start_train_offset + train_days

    def to_ts(dt):
        return int(dt.timestamp())

    def range_to_ts(start, end):
        return to_ts(start), to_ts(end)

    if end_train_offset < total_days:
        train_start = start_total + pd.Timedelta(days=start_train_offset)
        train_end = start_total + pd.Timedelta(days=end_train_offset)
        train_ranges = [(train_start, train_end)]
    else:
        train_ranges = [
            (start_total + pd.Timedelta(days=start_train_offset), start_total + pd.Timedelta(days=total_days)),
            (start_total, start_total + pd.Timedelta(days=end_train_offset - total_days))
        ]

    start_test_offset = end_train_offset % total_days
    end_test_offset = start_test_offset + test_days
    if end_test_offset < total_days:
        test_ranges = [(start_total + pd.Timedelta(days=start_test_offset),
                        start_total + pd.Timedelta(days=end_test_offset))]
    else:
        test_ranges = [
            (start_total + pd.Timedelta(days=start_test_offset), start_total + pd.Timedelta(days=total_days)),
            (start_total, start_total + pd.Timedelta(days=end_test_offset - total_days))
        ]

    train_ts = [(to_ts(s), to_ts(e)) for s,e in train_ranges]
    test_ts = [(to_ts(s), to_ts(e)) for s,e in test_ranges]
    return train_ts, test_ts

def parse_size(size: str):
    a,b = size.split("_")
    return int(a), int(b)
