import os, requests, pandas as pd
from dash import Dash, dcc, html, Input, Output
import plotly.graph_objs as go

WEBMASTER = os.getenv("WEBMASTER_URL", "http://webmaster:8000")

app = Dash(__name__)
server = app.server

def fetch_latest():
    r = requests.get(f"{WEBMASTER}/scenarios/latest_metrics")
    if r.status_code != 200:
        return None
    data = r.json()
    df = pd.DataFrame(data["metrics"])
    if not df.empty:
        df["metric_means"] = df["metric_means"].apply(eval)
        df["metric_iqrs"] = df["metric_iqrs"].apply(eval)
    return df

df = fetch_latest()
io_ids = sorted(df["io_id"].unique()) if df is not None and not df.empty else []
models = sorted(df["model"].unique()) if df is not None and not df.empty else []

app.layout = html.Div([
    html.H2("Freezer Anomalies — Dashboard"),
    html.Div([
        html.Label("IO ID"),
        dcc.Dropdown(io_ids, io_ids[0] if io_ids else None, id="io"),
        html.Label("Модель"),
        dcc.Dropdown(models, models[0] if models else None, id="model"),
    ], style={"display":"grid", "gridTemplateColumns":"1fr 1fr", "gap":"12px", "maxWidth":"600px"}),
    html.Br(),
    dcc.Graph(id="metrics-bar"),
    html.Div(id="table-div")
])

@app.callback(
    Output("metrics-bar","figure"),
    Output("table-div","children"),
    Input("io","value"),
    Input("model","value")
)
def update(io, model):
    df = fetch_latest()
    if df is None or df.empty or io is None or model is None:
        return go.Figure(), html.Div("Нет данных")
    dff = df[(df["io_id"]==io) & (df["model"]==model)]
    if dff.empty:
        return go.Figure(), html.Div("Нет данных")
    best = dff.iloc[dff["metric_means"].apply(lambda m: m.get("roc_auc",0)).argmax()]
    means = best["metric_means"]
    iqrs = best["metric_iqrs"]
    fig = go.Figure(data=[
        go.Bar(name="mean", x=list(means.keys()), y=list(means.values()), error_y=dict(type='data', array=[iqrs.get(k,0) for k in means.keys()]))
    ])
    fig.update_layout(title=f"Лучшие метрики: IO={io}, модель={model}", yaxis_title="score")
    info = html.Pre(f"size={best['size']} window={best['window_size']} encoding={best['encoding']}\nparams={best['best_params']}")
    return fig, info

if __name__ == "__main__":
    app.run_server(host="0.0.0.0", port=8050, debug=False)
