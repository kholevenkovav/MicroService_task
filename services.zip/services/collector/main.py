import os, io, yaml
import pandas as pd
from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from services_shared.utils import setup_logger

DATA_DIR = os.getenv("DATA_DIR", "/data")

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = f.read()
    raw = raw.replace("${DATA_DIR:/data}", DATA_DIR)
    return yaml.safe_load(raw)

cfg = load_config()
logger = setup_logger("collector", os.getenv("LOGS_DIR", "/logs"))

app = FastAPI(title="Collector Service", version="1.0")

def read_csv(kind: str) -> pd.DataFrame:
    fname = cfg["files"][kind]
    fpath = os.path.join(cfg["data_path"], fname)
    if not os.path.exists(fpath):
        raise HTTPException(status_code=404, detail=f"Файл {fpath} не найден. Поместите CSV в {cfg['data_path']}.")
    df = pd.read_csv(fpath)
    cols = [c.strip().lower() for c in df.columns]
    df.columns = cols
    for c in ["value_min","value_max"]:
        if c in df.columns:
            df = df.drop(columns=[c])
    return df

@app.get("/batch")
def get_batch(io_id: Optional[str] = None,
              start_ts: Optional[int] = None,
              end_ts: Optional[int] = None,
              annotated: bool = False,
              limit: int = 10000):
    kind = "annotated" if annotated else "freezer"
    df = read_csv(kind)
    if io_id:
        df = df[df["io_id"].astype(str) == str(io_id)]
    if start_ts is not None:
        df = df[df["event_timestamp"] >= int(start_ts)]
    if end_ts is not None:
        df = df[df["event_timestamp"] < int(end_ts)]
    df = df.sort_values("event_timestamp").head(limit)
    logger.info(f"/batch kind={kind} io_id={io_id} rows={len(df)}")
    return JSONResponse(content=df.to_dict(orient="records"))
