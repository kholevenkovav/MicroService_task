from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any

class TrainConfig(BaseModel):
    window_sizes: List[int] = Field(default_factory=lambda: [1,5,10,15,30,60])
    splits: List[str] = Field(default_factory=lambda: ["70_30","50_50","30_70"])
    shifts: int = 5
    time_encodings: List[str] = Field(default_factory=lambda: ["one_hot", "sin_cos", "cyclic", "sin_cos_cyclic"])
    models: List[str] = Field(default_factory=lambda: ["IF","OCSVM","DBSCAN","LOF","PCA","IF-PCA","OCSVM-PCA"])
    contamination: float = 0.04

class TrainRequest(BaseModel):
    io_ids: Optional[List[str]] = None
    config: TrainConfig = TrainConfig()

class MetricRow(BaseModel):
    io_id: str
    model: str
    size: str
    window_size: int
    encoding: str
    metric_means: Dict[str, float]
    metric_iqrs: Dict[str, float]
    best_params: Optional[Dict[str, Any]] = None

class BatchRequest(BaseModel):
    io_id: Optional[str] = None
    start_ts: Optional[int] = None
    end_ts: Optional[int] = None
    annotated: bool = False
    limit: Optional[int] = 10000
