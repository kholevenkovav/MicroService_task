import os, logging

def setup_logger(name: str, logs_dir: str = "/logs"):
    os.makedirs(logs_dir, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(os.path.join(logs_dir, f"{name}.log"))
    fh.setLevel(logging.INFO)
    fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(fmt)
    if not logger.handlers:
        logger.addHandler(fh)
    return logger
