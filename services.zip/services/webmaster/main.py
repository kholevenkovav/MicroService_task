import os, yaml, requests
from fastapi import FastAPI, HTTPException
from services_shared.schemas import TrainRequest
from services_shared.utils import setup_logger

def load_config():
    cfg_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(cfg_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

cfg = load_config()
logger = setup_logger("webmaster", os.getenv("LOGS_DIR","/logs"))

app = FastAPI(title="Web Master (API Gateway)", version="1.0")

@app.post("/scenarios/train_evaluate")
def scenario_train_evaluate(req: TrainRequest):
    r = requests.post(f"{cfg['ml_url']}/train_evaluate", json=req.model_dump())
    if r.status_code != 200:
        raise HTTPException(r.status_code, r.text)
    return r.json()

@app.get("/scenarios/latest_metrics")
def latest_metrics():
    run = requests.get(f"{cfg['storage_url']}/runs/latest")
    if run.status_code != 200:
        raise HTTPException(run.status_code, run.text)
    rid = run.json()["id"]
    mets = requests.get(f"{cfg['storage_url']}/metrics/by_run/{rid}")
    if mets.status_code != 200:
        raise HTTPException(mets.status_code, mets.text)
    return {"run_id": rid, "metrics": mets.json()}
